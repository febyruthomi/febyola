<?php

$ sudo mysqli -p -u root;
?>